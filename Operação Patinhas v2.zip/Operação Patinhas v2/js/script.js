
/* ETAPA 4.3 — SCRIPT DO SITE */

/* Máscara de CPF */
const cpf = document.getElementById("cpf");

if (cpf) {
    cpf.addEventListener("input", function () {
        let valor = cpf.value.replace(/\D/g, "").slice(0, 11);

        valor = valor.replace(/(\d{3})(\d)/, "$1.$2");
        valor = valor.replace(/(\d{3})(\d)/, "$1.$2");
        valor = valor.replace(/(\d{3})(\d{1,2})$/, "$1-$2");

        cpf.value = valor;
    });
}

/* Máscara de telefone */
const telefone = document.getElementById("telefone");

if (telefone) {
    telefone.addEventListener("input", function () {
        let valor = telefone.value.replace(/\D/g, "").slice(0, 11);

        if (valor.length > 10) {
            valor = valor.replace(
                /(\d{2})(\d{5})(\d{1,4})/,
                "($1) $2-$3"
            );
        } else if (valor.length > 6) {
            valor = valor.replace(
                /(\d{2})(\d{4})(\d{1,4})/,
                "($1) $2-$3"
            );
        } else if (valor.length > 2) {
            valor = valor.replace(/(\d{2})(\d+)/, "($1) $2");
        } else if (valor.length > 0) {
            valor = "(" + valor;
        }

        telefone.value = valor;
    });
}

/* Máscara de CEP */
const cep = document.getElementById("cep");

if (cep) {
    cep.addEventListener("input", function () {
        let valor = cep.value.replace(/\D/g, "").slice(0, 8);

        if (valor.length > 5) {
            valor = valor.replace(/(\d{5})(\d+)/, "$1-$2");
        }

        cep.value = valor;
    });
}

/* Menu hambúrguer */
const botaoMenu = document.getElementById("botao-menu");
const listaMenu = document.getElementById("lista-menu");

if (botaoMenu && listaMenu) {
    botaoMenu.addEventListener("click", function () {
        const menuAberto =
            botaoMenu.getAttribute("aria-expanded") === "true";

        botaoMenu.setAttribute(
            "aria-expanded",
            String(!menuAberto)
        );

        listaMenu.classList.toggle("menu-aberto", !menuAberto);

        botaoMenu.textContent = menuAberto ? "☰ Menu" : "✕ Fechar";
    });
}

/* ETAPA 4.4 — CONTROLE DO DROPDOWN */
const botoesDropdown = document.querySelectorAll(".link-dropdown");

botoesDropdown.forEach(function (botao) {
    botao.addEventListener("click", function () {
        const itemDropdown = botao.closest(".item-dropdown");
        const estaAberto = itemDropdown.classList.contains("submenu-aberto");

        itemDropdown.classList.toggle("submenu-aberto", !estaAberto);
        botao.setAttribute("aria-expanded", String(!estaAberto));
    });
});

/* =========================
   COMPONENTES DE FEEDBACK
   ========================= */

const botaoToast = document.getElementById("botao-toast");
const mensagemToast = document.getElementById("mensagem-toast");

const botaoModal = document.getElementById("botao-modal");
const modalFundo = document.getElementById("modal-fundo");
const fecharModal = document.getElementById("fechar-modal");

let temporizadorToast;

/* Exibe o toast por 3 segundos */
if (botaoToast && mensagemToast) {
    botaoToast.addEventListener("click", function () {
        mensagemToast.hidden = false;

        clearTimeout(temporizadorToast);

        temporizadorToast = setTimeout(function () {
            mensagemToast.hidden = true;
        }, 3000);
    });
}

/* Abre o modal */
if (botaoModal && modalFundo && fecharModal) {
    botaoModal.addEventListener("click", function () {
        modalFundo.hidden = false;
        fecharModal.focus();
    });

    /* Fecha pelo botão */
    fecharModal.addEventListener("click", function () {
        modalFundo.hidden = true;
        botaoModal.focus();
    });

    /* Fecha ao clicar fora da janela */
    modalFundo.addEventListener("click", function (evento) {
        if (evento.target === modalFundo) {
            modalFundo.hidden = true;
            botaoModal.focus();
        }
    });

    /* Fecha com a tecla Escape */
    document.addEventListener("keydown", function (evento) {
        if (evento.key === "Escape" && !modalFundo.hidden) {
            modalFundo.hidden = true;
            botaoModal.focus();
        }
    });
}
