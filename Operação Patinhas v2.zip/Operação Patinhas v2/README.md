# 🐾 Operação Patinhas

## 📌 Sobre o projeto

A **Operação Patinhas** é um projeto acadêmico de desenvolvimento web que simula uma plataforma para uma organização fictícia de proteção animal.

O objetivo é divulgar iniciativas de adoção responsável, apresentar projetos sociais, incentivar a participação de voluntários na causa animal e também praticar o desenvolvimento **Front-End**.

## 🛠️ Tecnologias utilizadas

- **HTML5:** estrutura e conteúdo das páginas.
- **CSS3:** estilização e organização visual.
- **JavaScript:** funcionalidades e máscaras de entrada para CPF, telefone e CEP.

## 📂 Estrutura do projeto

```text
PROJETO-01/
├── css/
│   └── style.css
├── js/
│   └── script.js
├── img/
│   └── imagens do projeto
├── index.html
├── projetos.html
├── cadastro.html
└── README.md
```

## 🌐 Páginas do site

- **Página inicial (`index.html`):** apresentação da organização, sua missão e informações institucionais.
- **Projetos (`projetos.html`):** divulgação de campanhas, iniciativas e histórias de sucesso.
- **Cadastro (`cadastro.html`):** formulário para cadastro de voluntários.

## ▶️ Como executar

1. Baixe ou clone este repositório.
2. Abra a pasta do projeto no Visual Studio Code ou em outro editor.
3. Abra o arquivo `index.html` em um navegador.
4. Navegue pelas páginas utilizando o menu do site.

**Dica:** você também pode utilizar a extensão Live Server no Visual Studio Code para visualizar o site durante o desenvolvimento.

## ⚠️ Observações

Este projeto tem finalidade acadêmica e demonstrativa. O formulário de cadastro ainda depende de uma implementação de *back-end* para armazenar e processar os dados enviados.

**Atenção:** não insira dados pessoais reais no formulário, pois ele foi desenvolvido para fins de demonstração.

